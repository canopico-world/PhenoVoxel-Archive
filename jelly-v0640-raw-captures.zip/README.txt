PhenoVoxel Archive v0.6.40: 117 actual attributed compiled-view PNGs.
All final views used compatibility rendering after a graphics-context interruption. They are authored, unmeasured studies, not biological validation.
Original reference-model geometry and capture layout: PhenoVoxel Archive contributors, MIT.
Aurelia retains n- creator surface, Simple Moon Jellyfish (Baked Animation), CC BY 4.0. Runtime alignment, visibility and finite playback curation are disclosed derivatives.
Artist source: https://sketchfab.com/3d-models/simple-moon-jellyfish-baked-animation-3d911c511f2744ec9bfb99d46d2d6e14
License: https://creativecommons.org/licenses/by/4.0/
Record metadata: CC BY 4.0. No organism photographs or private paper figures are in this archive. Separately licensed photographs and individual limitations are linked in https://www.canopico.tech/phenovoxel/jellyfish-review-v0640.html
Source: https://github.com/canopico-world/PhenoVoxel-Archive
