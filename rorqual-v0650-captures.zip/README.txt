60 actual v0.6.50 main-viewer PNGs, byte-exact to individually inspected compiled views. Software compatibility only. Each PNG retains creator, source and license. Blue Whale - Textured: Bohdan Lvov, CC BY 4.0; Game-ready Humpback whale: Allie2k, CC BY 4.0. Runtime exterior derivatives: PhenoVoxel Archive contributors, CC BY 4.0. https://creativecommons.org/licenses/by/4.0/
Unmeasured geometry/timing, not organism photographs or independent biological validation. No paper figure, source video or user attachment included.
Report: https://www.canopico.tech/phenovoxel/rorqual-anterior-v0650.html
