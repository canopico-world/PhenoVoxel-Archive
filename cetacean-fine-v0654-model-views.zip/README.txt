Actual same-viewer PNGs; authored scale and timing. Software compatibility only. No biological accuracy certification.
Narwhal body Cosmic_dust CC BY4.0 with disclosed runtime derivatives; other original geometry/maps PhenoVoxel Archive MIT. Each PNG includes credit.
